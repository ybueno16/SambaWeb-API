package com.br.SambaWebAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SambaWebApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SambaWebApiApplication.class, args);
	}

}
